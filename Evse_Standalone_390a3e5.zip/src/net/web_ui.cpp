﻿#include "web_ui.h"
#include <WiFi.h>
#include <WiFiMulti.h>

#include <WebServer.h>
#include <ElegantOTA.h>
#include <ArduinoOTA.h>
#include <ESPmDNS.h>
#include <Preferences.h>
#include <math.h>

#include "app_config.h"
#include "app_pins.h"
#include "pilot/pilot.h"
#include "io/relay.h"

// EKSÄ°K OLAN KÃœTÃœPHANE
#include "io/current_sensor.h"

// DeÄŸiÅŸkenleri dÄ±ÅŸarÄ±dan alÄ±yoruz
extern float CP_DIVIDER_RATIO;
extern float TH_A_MIN, TH_B_MIN, TH_C_MIN, TH_D_MIN, TH_E_MIN;
extern float marginUp, marginDown;
extern int   stableCount;
extern int   loopIntervalMs;
extern uint32_t relayOnDelayMs;
extern uint32_t relayOffDelayMs;
extern float g_powerW;
extern float g_energyKWh;
extern uint32_t g_chargeSeconds;
extern int g_phaseCount;
extern float g_currentLimitA;
extern int g_chargeMode;
extern bool g_sessionLive;
extern uint32_t g_sessionLiveStartSec;
extern uint32_t g_sessionLiveSeconds;
extern float g_sessionLiveEnergyKWh;
extern uint32_t g_histStartSec[20];
extern uint32_t g_histDurationSec[20];
extern float g_histEnergyKWh[20];
extern float g_histAvgPowerW[20];
extern uint8_t g_histPhaseCount[20];
extern int g_histCount;
extern int g_histHead;
extern void resetChargeData(bool clearHistory);
extern void resetHistoryData();

static void pulseGpio(uint8_t pin) {
  digitalWrite(pin, HIGH);
  delay(RELAY_LATCH_PULSE_MS);
  digitalWrite(pin, LOW);
}

#ifndef EVSE_AP_SSID
#define EVSE_AP_SSID "EVSE"
#endif

#ifndef EVSE_AP_PASSWORD
#define EVSE_AP_PASSWORD "12345678"
#endif

#ifndef EVSE_ADMIN_USER
#define EVSE_ADMIN_USER "admin"
#endif

#ifndef EVSE_ADMIN_PASSWORD
#define EVSE_ADMIN_PASSWORD "rotosis123"
#endif

#ifndef EVSE_HOSTNAME
#define EVSE_HOSTNAME "evse"
#endif

#ifndef EVSE_OTA_HOSTNAME
#define EVSE_OTA_HOSTNAME EVSE_HOSTNAME
#endif

#ifndef EVSE_OTA_PASSWORD
#define EVSE_OTA_PASSWORD ""
#endif

#ifndef EVSE_WIFI_1_LOC
#define EVSE_WIFI_1_LOC "Ev"
#endif
#ifndef EVSE_WIFI_1_SSID
#define EVSE_WIFI_1_SSID "FiberHGW_ZTN2TY"
#endif
#ifndef EVSE_WIFI_1_PASS
#define EVSE_WIFI_1_PASS "PzeuKE7X44Rs"
#endif

#ifndef EVSE_WIFI_2_LOC
#define EVSE_WIFI_2_LOC "Rotosis"
#endif
#ifndef EVSE_WIFI_2_SSID
#define EVSE_WIFI_2_SSID "Rotosis_Ofis"
#endif
#ifndef EVSE_WIFI_2_PASS
#define EVSE_WIFI_2_PASS "Rotosis2020"
#endif

#ifndef EVSE_WIFI_3_LOC
#define EVSE_WIFI_3_LOC "Ceylan Robot"
#endif
#ifndef EVSE_WIFI_3_SSID
#define EVSE_WIFI_3_SSID "CEYLAN-ROBOT"
#endif
#ifndef EVSE_WIFI_3_PASS
#define EVSE_WIFI_3_PASS "Mahfer123."
#endif

#ifndef EVSE_WIFI_4_LOC
#define EVSE_WIFI_4_LOC "Rotosis Atolye"
#endif
#ifndef EVSE_WIFI_4_SSID
#define EVSE_WIFI_4_SSID "Rotosis_Atolye"
#endif
#ifndef EVSE_WIFI_4_PASS
#define EVSE_WIFI_4_PASS "Rotosis2021@"
#endif

#ifndef EVSE_WIFI_5_LOC
#define EVSE_WIFI_5_LOC "Test"
#endif
#ifndef EVSE_WIFI_5_SSID
#define EVSE_WIFI_5_SSID "test"
#endif
#ifndef EVSE_WIFI_5_PASS
#define EVSE_WIFI_5_PASS "12345678"
#endif

static const char* kAdminUser = EVSE_ADMIN_USER;
static const char* kAdminPassword = EVSE_ADMIN_PASSWORD;
static const char* kHostName = EVSE_HOSTNAME;
static const char* kOtaHostname = EVSE_OTA_HOSTNAME;
static const char* kOtaPassword = EVSE_OTA_PASSWORD;

struct KnownWifi {
  const char* location;
  const char* ssid;
  const char* password;
};

static const KnownWifi kKnownWifis[] = {
  {EVSE_WIFI_1_LOC, EVSE_WIFI_1_SSID, EVSE_WIFI_1_PASS},
  {EVSE_WIFI_2_LOC, EVSE_WIFI_2_SSID, EVSE_WIFI_2_PASS},
  {EVSE_WIFI_3_LOC, EVSE_WIFI_3_SSID, EVSE_WIFI_3_PASS},
  {EVSE_WIFI_4_LOC, EVSE_WIFI_4_SSID, EVSE_WIFI_4_PASS},
  {EVSE_WIFI_5_LOC, EVSE_WIFI_5_SSID, EVSE_WIFI_5_PASS}
};

WiFiMulti wifiMulti;
static WebServer server(80);
static bool wifiEventsReady = false;
static uint32_t s_resetTotalCount = 0;
static uint32_t s_resetNowCount = 0;
static uint32_t s_resetHistoryCount = 0;
static uint32_t s_resetLastSec = 0;
static uint8_t s_resetLastModeId = 0;
static Preferences s_resetPrefs;
static bool s_resetPrefsReady = false;

static bool hasText(const char* value) {
  return value != nullptr && value[0] != '\0';
}

static void refreshMdns() {
  static bool mdnsStarted = false;
  bool staOk = (WiFi.status() == WL_CONNECTED && WiFi.localIP()[0] != 0);

  if (!staOk) {
    if (mdnsStarted) {
      MDNS.end();
      mdnsStarted = false;
      Serial.println("[mDNS] Stopped");
    }
    return;
  }

  if (!mdnsStarted) {
    if (!MDNS.begin(kHostName)) {
      Serial.println("[mDNS] Start failed");
      return;
    }
    MDNS.addService("http", "tcp", 80);
    MDNS.addService("arduino", "tcp", 3232);
    mdnsStarted = true;
    Serial.print("[mDNS] Ready: http://");
    Serial.print(kHostName);
    Serial.println(".local");
  }
}

static void setupArduinoOta() {
  ArduinoOTA.setHostname(kOtaHostname);
  if (hasText(kOtaPassword)) {
    ArduinoOTA.setPassword(kOtaPassword);
  }

  ArduinoOTA.onStart([]() {
    Serial.println("[OTA] Start");
  });

  ArduinoOTA.onEnd([]() {
    Serial.println("\n[OTA] End");
  });

  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    static uint32_t lastPct = 101;
    uint32_t pct = (total > 0) ? ((progress * 100U) / total) : 0U;
    if (pct != lastPct && (pct % 10U == 0U || pct == 100U)) {
      Serial.printf("[OTA] Progress: %u%%\n", (unsigned)pct);
      lastPct = pct;
    }
  });

  ArduinoOTA.onError([](ota_error_t error) {
    Serial.printf("[OTA] Error[%u]\n", (unsigned)error);
  });

  ArduinoOTA.begin();
  Serial.println("[OTA] Ready (port 3232)");
  Serial.print("[OTA] Hostname: ");
  Serial.println(kOtaHostname);
}

static int clampIntArg(const String& v, int minVal, int maxVal) {
  long parsed = v.toInt();
  if (parsed < minVal) return minVal;
  if (parsed > maxVal) return maxVal;
  return (int)parsed;
}

static float clampFloatArg(const String& v, float minVal, float maxVal, float fallback) {
  float parsed = v.toFloat();
  if (!(parsed == parsed)) return fallback; // NaN guard
  if (parsed < minVal) return minVal;
  if (parsed > maxVal) return maxVal;
  return parsed;
}

static float safeFinite(float v) {
  if (isnan(v) || isinf(v)) return 0.0f;
  return v;
}

static const char* wifiLocationForSsid(const String& connectedSsid) {
  for (size_t i = 0; i < (sizeof(kKnownWifis) / sizeof(kKnownWifis[0])); i++) {
    if (connectedSsid == kKnownWifis[i].ssid) return kKnownWifis[i].location;
  }
  return "Bilinmiyor";
}

static bool requireAdminAuth() {
  if (server.authenticate(kAdminUser, kAdminPassword)) {
    return true;
  }
  server.requestAuthentication(BASIC_AUTH, "RotosisEVSE Admin", "Sifre gerekli");
  return false;
}

static const char* chargeModeLabel(int mode) {
  if (mode == 1) return "START";
  if (mode == 2) return "STOP";
  return "AUTO";
}

static const char* resetModeLabel(uint8_t modeId) {
  if (modeId == 1) return "ANLIK";
  if (modeId == 2) return "GECMIS";
  if (modeId == 3) return "ANLIK+GECMIS";
  return "YOK";
}

struct ResetStatsPersist {
  uint32_t total;
  uint32_t nowCount;
  uint32_t historyCount;
  uint32_t lastSec;
  uint8_t lastModeId;
};

static void loadResetStats() {
  if (!s_resetPrefsReady) return;
  ResetStatsPersist stats = {};
  size_t got = s_resetPrefs.getBytes("rstStats", &stats, sizeof(stats));
  if (got != sizeof(stats)) return;

  s_resetTotalCount = stats.total;
  s_resetNowCount = stats.nowCount;
  s_resetHistoryCount = stats.historyCount;
  s_resetLastSec = stats.lastSec;
  s_resetLastModeId = (stats.lastModeId <= 3) ? stats.lastModeId : 0;
}

static void saveResetStats() {
  if (!s_resetPrefsReady) return;
  ResetStatsPersist stats = {};
  stats.total = s_resetTotalCount;
  stats.nowCount = s_resetNowCount;
  stats.historyCount = s_resetHistoryCount;
  stats.lastSec = s_resetLastSec;
  stats.lastModeId = s_resetLastModeId;
  s_resetPrefs.putBytes("rstStats", &stats, sizeof(stats));
}

static void noteResetEvent(bool clearNow, bool clearHistory) {
  if (!clearNow && !clearHistory) return;
  s_resetTotalCount++;
  if (clearNow) s_resetNowCount++;
  if (clearHistory) s_resetHistoryCount++;
  s_resetLastSec = millis() / 1000UL;
  if (clearNow && clearHistory) {
    s_resetLastModeId = 3;
  } else if (clearNow) {
    s_resetLastModeId = 1;
  } else {
    s_resetLastModeId = 2;
  }
  saveResetStats();
}

static const char USER_HTML[] PROGMEM = R"HTML(
<!DOCTYPE html><html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>RotosisEVSE</title>
<style>
*{box-sizing:border-box}
:root{
  --bg0:#071017;
  --bg1:#0c1d29;
  --panel:#102635e8;
  --panel2:#133043;
  --line:#2f6072;
  --text:#f1fbff;
  --muted:#9dc0ce;
  --accent:#4fe7b1;
  --accentSoft:#bfffe6;
  --warn:#ffc861;
  --err:#ff8b7c;
  --sky:#72d7ff;
}
html,body{margin:0;padding:0}
body{
  font-family:"Trebuchet MS","Franklin Gothic Medium","Segoe UI",sans-serif;
  color:var(--text);
  min-height:100vh;
  background:
    radial-gradient(560px 280px at 50% -10%, #24445b 0%, transparent 70%),
    linear-gradient(180deg, var(--bg0), var(--bg1) 62%, #08131b);
}
body.state-A{--accent:var(--sky);--accentSoft:#c7f3ff}
body.state-B{--accent:#8cbaff;--accentSoft:#dce8ff}
body.state-C,body.state-D{--accent:#4fe7b1;--accentSoft:#c5ffe5}
body.state-E,body.state-F{--accent:var(--err);--accentSoft:#ffd0c9}
.app{
  max-width:430px;
  margin:0 auto;
  padding:16px 14px 18px;
}
.top{
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:10px;
  margin-bottom:12px;
}
.brand{
  font-size:28px;
  font-weight:700;
  letter-spacing:.2px;
}
.brandSub{
  margin-top:2px;
  color:var(--muted);
  font-size:12px;
}
.sync{
  border:1px solid var(--accent);
  background:#133547;
  color:var(--accentSoft);
  border-radius:999px;
  padding:7px 11px;
  font-size:12px;
  font-family:"Consolas","Lucida Console",monospace;
}
.sync.wait{
  border-color:#866f42;
  color:#ffdca0;
  background:#352715;
}
.card{
  border:1px solid var(--line);
  border-radius:28px;
  background:linear-gradient(180deg,var(--panel),#0e2230);
  box-shadow:0 20px 40px #00000030;
}
.hero{
  padding:16px;
  overflow:hidden;
  position:relative;
}
.hero::after{
  content:"";
  position:absolute;
  width:180px;
  height:180px;
  right:-55px;
  top:-55px;
  border-radius:999px;
  background:radial-gradient(circle,var(--accent) 0%, transparent 72%);
  opacity:.18;
}
.chipRow{
  display:grid;
  grid-template-columns:repeat(3,minmax(0,1fr));
  gap:8px;
}
.chip{
  border:1px solid #3f6f83;
  border-radius:999px;
  padding:7px 8px;
  text-align:center;
  font-size:11px;
  font-family:"Consolas","Lucida Console",monospace;
  background:#112d3d;
  color:#ddf6ff;
}
.chip.main{
  border-color:var(--accent);
  color:var(--accentSoft);
}
.stateName{
  margin-top:14px;
  font-size:27px;
  font-weight:700;
}
.stateHint{
  margin-top:4px;
  color:var(--muted);
  font-size:14px;
}
.current{
  margin-top:18px;
  font-size:56px;
  line-height:.95;
  font-weight:700;
  letter-spacing:-1px;
}
.currentSub{
  margin-top:6px;
  color:var(--muted);
  font-size:12px;
}
.meter{
  margin-top:14px;
  height:12px;
  border-radius:999px;
  overflow:hidden;
  border:1px solid #3a6677;
  background:#0d1f2b;
}
.meter > span{
  display:block;
  height:100%;
  width:0%;
  background:linear-gradient(90deg,var(--accent),var(--accentSoft));
  box-shadow:0 0 14px #59f3ce66;
  transition:width .35s ease;
}
.meterMeta{
  margin-top:7px;
  display:flex;
  justify-content:space-between;
  gap:10px;
  color:var(--muted);
  font-size:12px;
}
.actions{
  margin-top:12px;
  display:grid;
  grid-template-columns:repeat(2,minmax(0,1fr));
  gap:10px;
}
.btn{
  border:1px solid #3c6d7f;
  border-radius:18px;
  padding:13px 10px;
  background:#133243;
  color:var(--text);
  text-decoration:none;
  text-align:center;
  font-size:15px;
}
.btn.ok{background:#15473b;border-color:#4fc49e}
.btn.stop{background:#4e262d;border-color:#d37c75}
.btn.ghost{background:#143243;border-color:#5a8395}
.btn.install{
  grid-column:1 / -1;
  display:none;
}
.stats{
  margin-top:12px;
  display:grid;
  grid-template-columns:repeat(3,minmax(0,1fr));
  gap:10px;
}
.stat{
  padding:12px 10px;
  border:1px solid var(--line);
  border-radius:20px;
  background:linear-gradient(180deg,var(--panel2),#10293a);
  text-align:center;
}
.stat span{
  display:block;
  color:var(--muted);
  font-size:11px;
  text-transform:uppercase;
  letter-spacing:.7px;
}
.stat strong{
  display:block;
  margin-top:7px;
  font-size:23px;
  line-height:1.05;
  font-family:"Consolas","Lucida Console",monospace;
}
.stat small{
  display:block;
  margin-top:5px;
  color:#c9e3ee;
  font-size:11px;
}
.statusCard{
  margin-top:12px;
  padding:14px;
}
.statusCard.ok{
  border-color:#46a886;
  background:linear-gradient(180deg,#163c33,#112820);
}
.statusCard.warn{
  border-color:#b48b4b;
  background:linear-gradient(180deg,#43311d,#322414);
}
.statusCard.err{
  border-color:#c06862;
  background:linear-gradient(180deg,#49242b,#34181f);
}
.statusText{
  font-size:22px;
  font-weight:700;
}
.statusMeta{
  margin-top:5px;
  font-size:13px;
  color:#ecf7fb;
}
.phaseRow{
  margin-top:12px;
  display:grid;
  grid-template-columns:repeat(3,minmax(0,1fr));
  gap:8px;
}
.phaseChip{
  border:1px solid #3c697b;
  border-radius:18px;
  padding:10px 8px;
  background:#102a38cc;
  text-align:center;
}
.phaseChip span{
  display:block;
  color:#b7d9e8;
  font-size:11px;
}
.phaseChip strong{
  display:block;
  margin-top:5px;
  font-size:15px;
  font-family:"Consolas","Lucida Console",monospace;
}
.meta{
  margin-top:12px;
  padding-top:12px;
  border-top:1px solid #ffffff22;
  display:grid;
  gap:6px;
}
.metaLine{
  font-size:12px;
  color:#d9eef6;
  word-break:break-word;
}
.metaLine.muted{color:#bdd7e2}
.stats{
  align-items:stretch;
}
@media(max-width:390px){
  .brand{font-size:24px}
  .current{font-size:48px}
  .stats{gap:8px}
  .stat strong{font-size:20px}
}
@media(max-width:520px){
  .app{padding:14px 12px 18px}
}
</style>
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#102635">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="RotosisEVSE">
</head><body class="state-A">
<div class="app">
  <div class="top">
    <div>
      <div class="brand">RotosisEVSE</div>
      <div class="brandSub">Mobil ana ekran</div>
    </div>
    <div class="sync wait" id="sync">WAIT</div>
  </div>

  <section class="card hero">
    <div class="chipRow">
      <span class="chip main" id="state">STATE:A</span>
      <span class="chip" id="relay">R:RESET</span>
      <span class="chip" id="modeLbl">MOD:AUTO</span>
    </div>
    <div class="stateName" id="stateName">Hazir</div>
    <div class="stateHint" id="stateHint">Arac bekleniyor</div>
    <div class="current" id="it">0.00A</div>
    <div class="currentSub">Toplam akim</div>
    <div class="meter"><span id="loadFill"></span></div>
    <div class="meterMeta"><span>Yuk</span><strong id="loadPct">0%</strong></div>
  </section>

  <div class="actions">
    <button class="btn ok" onclick="chargeCmd(1)">Baslat</button>
    <button class="btn stop" onclick="chargeCmd(2)">Durdur</button>
    <button class="btn ghost" onclick="chargeCmd(0)">AUTO</button>
    <a class="btn ghost" href="/admin">Ayarlar</a>
    <button class="btn ghost install" id="installBtn">Install App</button>
  </div>

  <div class="stats">
    <div class="stat"><span>Guc</span><strong><span id="pwr">0.00</span></strong><small>kW</small></div>
    <div class="stat"><span>Enerji</span><strong><span id="ekwh">0.000</span></strong><small>kWh</small></div>
    <div class="stat"><span>Sure</span><strong id="tsec">00:00</strong><small><span id="phase">-</span> Faz</small></div>
  </div>

  <section class="card statusCard ok" id="alarmBox">
    <div class="statusText" id="alarmText">Sistem normal</div>
    <div class="statusMeta" id="alarmMeta">Takip devam ediyor</div>

    <div class="phaseRow">
      <div class="phaseChip"><span>Faz 1</span><strong id="i1">0.00A</strong></div>
      <div class="phaseChip"><span>Faz 2</span><strong id="i2">0.00A</strong></div>
      <div class="phaseChip"><span>Faz 3</span><strong id="i3">0.00A</strong></div>
    </div>

    <div class="meta">
      <div class="metaLine" id="wifiLine">Wi-Fi: -</div>
      <div class="metaLine"><span id="host">-</span> | <span id="ip">-</span></div>
      <div class="metaLine muted" id="ts">-</div>
    </div>
  </section>
</div>
<script>
let deferredPrompt=null;
const stateMeta={
  A:{name:"Hazir",hint:"Arac bekleniyor"},
  B:{name:"Bagli",hint:"Arac baglandi"},
  C:{name:"Sarjda",hint:"Enerji veriliyor"},
  D:{name:"Havalandirma",hint:"Sarj suruyor"},
  E:{name:"Hata",hint:"Pilot hata durumu"},
  F:{name:"Kritik Hata",hint:"Koruma aktif"}
};
function fmtTime(sec){
  const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;
  if(h>0) return String(h).padStart(2,"0")+":"+String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");
  return String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");
}
function clamp(v,min,max){return Math.max(min,Math.min(max,v))}
function chargeCmd(mode){fetch('/charge_cmd?m='+mode).then(()=>pull()).catch(()=>{});}
function setSync(ok){
  const el=document.getElementById("sync");
  if(!el) return;
  el.textContent=ok?"LIVE":"WAIT";
  el.className=ok?"sync":"sync wait";
}
function updateState(st){
  document.body.className="state-"+st;
  document.getElementById("state").textContent="STATE:"+st;
  const meta=stateMeta[st]||stateMeta["A"];
  document.getElementById("stateName").textContent=meta.name;
  document.getElementById("stateHint").textContent=meta.hint;
}
function renderAlarm(level,text,state,staOk){
  const box=document.getElementById("alarmBox");
  if(box) box.className="card statusCard "+(level===2?"err":(level===1?"warn":"ok"));
  const txt=document.getElementById("alarmText");
  const meta=document.getElementById("alarmMeta");
  if(txt) txt.textContent=text||"Sistem normal";
  if(meta) meta.textContent="State:"+state+" | "+(staOk?"Wi-Fi bagli":"Wi-Fi yok");
}
function pull(){
  fetch('/status',{cache:'no-store'}).then(r=>r.json()).then(d=>{
    const ia=d.ia||0, ib=d.ib||0, ic=d.ic||0;
    const it=ia+ib+ic;
    const phaseCount=Math.max(1,d.phase||1);
    const totalLimit=phaseCount*Math.max(6,d.limitA||32);
    const loadPct=clamp((it/totalLimit)*100,0,100);
    document.getElementById('it').textContent=it.toFixed(2)+"A";
    document.getElementById('i1').textContent=ia.toFixed(2)+"A";
    document.getElementById('i2').textContent=ib.toFixed(2)+"A";
    document.getElementById('i3').textContent=ic.toFixed(2)+"A";
    if(d.pW!==undefined) document.getElementById('pwr').textContent=(d.pW/1000.0).toFixed(2);
    if(d.eKWh!==undefined) document.getElementById('ekwh').textContent=d.eKWh.toFixed(3);
    if(d.tSec!==undefined) document.getElementById('tsec').textContent=fmtTime(d.tSec);
    if(d.phase!==undefined) document.getElementById('phase').textContent=d.phase;
    if(d.rLbl!==undefined) document.getElementById('relay').textContent="R:"+d.rLbl;
    if(d.mode!==undefined) document.getElementById('modeLbl').textContent="MOD:"+d.mode;
    if(d.state!==undefined) updateState(d.state);
    if(d.ip!==undefined) document.getElementById('ip').textContent=d.ip;
    if(d.host!==undefined) document.getElementById('host').textContent=d.host;
    document.getElementById('loadFill').style.width=loadPct.toFixed(1)+"%";
    document.getElementById('loadPct').textContent=loadPct.toFixed(0)+"%";
    document.getElementById('ts').textContent="Son guncelleme: "+new Date().toLocaleTimeString();
    const wifiText=(d.wifiSsid&&d.wifiSsid!=="-") ? ("Wi-Fi: "+d.wifiSsid+((d.wifiLoc&&d.wifiLoc!=="-")?" / "+d.wifiLoc:"")) : "Wi-Fi: bagli degil";
    document.getElementById('wifiLine').textContent=wifiText;
    renderAlarm(d.alarmLv||0, d.alarmTxt||"Sistem normal", d.state||"A", !!d.staOk);
    setSync(true);
  }).catch(()=>{ setSync(false); });
}
window.addEventListener("beforeinstallprompt",(e)=>{
  e.preventDefault();
  deferredPrompt=e;
  const b=document.getElementById("installBtn");
  if(b) b.style.display="block";
});
document.addEventListener("click",(e)=>{
  if(e.target && e.target.id==="installBtn" && deferredPrompt){
    deferredPrompt.prompt();
    deferredPrompt.userChoice.finally(()=>{deferredPrompt=null;e.target.style.display="none";});
  }
});
if("serviceWorker" in navigator){
  window.addEventListener("load",function(){
    navigator.serviceWorker.register("/sw.js").catch(()=>{});
  });
}
setInterval(pull,1200);
pull();
</script>
</body></html>
)HTML";

static const char MANIFEST_JSON[] PROGMEM = R"JSON(
{
  "name": "RotosisEVSE",
  "short_name": "RotosisEVSE",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "background_color": "#08131c",
  "theme_color": "#0d1a2b",
  "icons": [
    {
      "src": "/app-icon.svg",
      "sizes": "192x192",
      "type": "image/svg+xml",
      "purpose": "any"
    },
    {
      "src": "/app-icon.svg",
      "sizes": "512x512",
      "type": "image/svg+xml",
      "purpose": "any"
    }
  ]
}
)JSON";

static const char SERVICE_WORKER_JS[] PROGMEM = R"JS(
const CACHE_NAME = "evse-pwa-v3";
const ASSETS = ["/", "/manifest.json", "/app-icon.svg"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  const path = url.pathname;
  const isLiveApi =
    path === "/status" ||
    path === "/history" ||
    path === "/data_reset" ||
    path === "/charge_cmd" ||
    path === "/calib_apply" ||
    path.startsWith("/relay") ||
    path === "/pulse_reset" ||
    path === "/pulse_set";

  if (isLiveApi) {
    event.respondWith(
      fetch(event.request).catch(() =>
        new Response("{}", { headers: { "Content-Type": "application/json" } })
      )
    );
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request).then((r) => r || caches.match("/")))
  );
});
)JS";

static const char APP_ICON_SVG[] PROGMEM = R"SVG(
<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0d1a2b"/>
      <stop offset="100%" stop-color="#173645"/>
    </linearGradient>
    <linearGradient id="bolt" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#9cf9e3"/>
      <stop offset="100%" stop-color="#36d0a7"/>
    </linearGradient>
  </defs>
  <rect x="16" y="16" width="480" height="480" rx="110" fill="url(#bg)"/>
  <rect x="132" y="84" width="248" height="344" rx="86" fill="#112b3a" stroke="#4ecaa8" stroke-width="18"/>
  <rect x="176" y="118" width="160" height="28" rx="14" fill="#4ecaa8"/>
  <polygon points="292,176 226,270 274,270 220,352 320,238 270,238" fill="url(#bolt)"/>
</svg>
)SVG";

static const char MAIN_HTML[] PROGMEM = R"HTML(
<!DOCTYPE html><html><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>RotosisEVSE Panel</title>
<style>
body{font-family:Arial;margin:0;background:#0b1220;color:#e8eefc}
.wrap{display:grid;grid-template-columns:1.2fr .8fr;gap:12px;padding:12px}
@media(max-width:900px){.wrap{grid-template-columns:1fr}}
.card{background:#111a2b;border:1px solid #20304a;border-radius:12px;padding:12px}
h2{margin:0 0 10px 0;font-size:14px;color:#b7c5e6}
.kv{display:grid;grid-template-columns:140px 1fr;gap:8px;margin:6px 0}
.k{color:#b7c5e6;font-size:12px}
.v{font-weight:700}
.mono{font-family:monospace;color:#00ffaa}
input{width:100%;padding:8px;border-radius:10px;border:1px solid #20304a;background:#0c1424;color:#e8eefc}
.btns{display:flex;flex-wrap:wrap;gap:8px}
button{padding:8px 10px;border-radius:10px;border:1px solid #20304a;background:#0c1424;color:#e8eefc;cursor:pointer}
.primary{background:rgba(0,200,150,.18);border-color:rgba(0,200,150,.45)}
.danger{background:rgba(255,77,77,.14);border-color:rgba(255,77,77,.40)}
.small{font-size:11px;color:#b7c5e6}
.sep{height:1px;background:#20304a;margin:10px 0}

.hero{background:linear-gradient(180deg, rgba(0,200,150,.10), rgba(0,0,0,0));border:1px solid #20304a;border-radius:12px;padding:10px;margin-bottom:10px}
.heroTop{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:6px}
.badge{font-family:monospace;font-size:12px;padding:4px 8px;border-radius:999px;border:1px solid rgba(0,200,150,.45);background:rgba(0,200,150,.12);color:#00ffaa}

</style></head><body>

<div class="wrap">
  <div class="card">
    <h2>CANLI VERÄ°LER</h2>
    <div class="kv"><div class="k">State (Stable/Raw)</div><div class="v mono"><span id="sStb">-</span> / <span id="sRaw">-</span></div></div>
    <div class="kv"><div class="k">CP High / Low</div><div class="v mono"><span id="cH">-</span> / <span id="cL">-</span></div></div>
    <div class="kv"><div class="k">ADC High / Low</div><div class="v mono"><span id="aH">-</span> / <span id="aL">-</span></div></div>

    <div class="sep"></div>
    <h2>Zamanlama ve HÄ±z AyarlarÄ±</h2>
    <div class="kv"><div class="k">Loop DÃ¶ngÃ¼sÃ¼ (ms)</div><div class="v"><input id="lInt" onfocus="p()" onblur="r()"></div></div>
    <div class="kv"><div class="k">RÃ¶le AÃ§ma (ms)</div><div class="v"><input id="onD" onfocus="p()" onblur="r()"></div></div>
    <div class="kv"><div class="k">RÃ¶le BÄ±rakma (ms)</div><div class="v"><input id="offD" onfocus="p()" onblur="r()"></div></div>
    <div class="kv"><div class="k">Stable Count</div><div class="v"><input id="stb" onfocus="p()" onblur="r()"></div></div>

    <div class="sep"></div>
    <h2>EÅŸikler / Kalibrasyon</h2>
    <div class="kv"><div class="k">Divider</div><div class="v"><input id="div" onfocus="p()" onblur="r()"></div></div>
    <div class="kv"><div class="k">TH_B / TH_C</div><div class="v" style="display:flex;gap:5px"><input id="thb" onfocus="p()" onblur="r()"> <input id="thc" onfocus="p()" onblur="r()"></div></div>
    <div class="kv"><div class="k">TH_D / TH_E</div><div class="v" style="display:flex;gap:5px"><input id="thd" onfocus="p()" onblur="r()"> <input id="the" onfocus="p()" onblur="r()"></div></div>

    <div class="btns" style="margin-top:10px">
      <button class="primary" onclick="applyCal()">UYGULA</button>
      <button onclick="pull(true)">YENÄ°LE</button>
    </div>
  </div>

  <div class="card">
    <div class="hero" id="displayPanel">
  <div class="heroTop">
    <div style="display:flex;gap:8px;align-items:center">
      <h2 style="margin:0">RotosisEVSE</h2>
      <span class="badge" id="badgeState">STATE:-</span>
    </div>
    <span class="badge" id="badgeRelay">R: -</span>
  </div>
  <div class="kv"><div class="k">I1 / I2 / I3</div><div class="v mono"><span id="i1">-</span> / <span id="i2">-</span> / <span id="i3">-</span> A</div></div>
  <div class="kv"><div class="k">Power</div><div class="v mono"><span id="pwr">-</span> kW</div></div>
  <div class="kv"><div class="k">Energy</div><div class="v mono"><span id="ekwh">-</span> kWh</div></div>
  <div class="kv"><div class="k">Time</div><div class="v mono"><span id="tsec">-</span></div></div>
  <div class="kv"><div class="k">Phase</div><div class="v mono"><span id="phase">-</span></div></div>
  <div class="kv"><div class="k">Wi-Fi</div><div class="v mono"><span id="wifiSsid">-</span> (<span id="wifiLoc">-</span>)</div></div>
  <div class="kv"><div class="k">IP</div><div class="v mono"><span id="ip">-</span></div></div>
  <div class="kv"><div class="k">Host</div><div class="v mono"><span id="host">-</span></div></div>
  <div class="kv"><div class="k">Relay</div><div class="v mono"><span id="rLbl">-</span></div></div>
</div>
    </div>

    <div class="sep"></div>

    <h2>RÃ¶le</h2>
    <div class="btns">
      <button class="primary" onclick="send('/relay?on=1')">MANUEL AÃ‡</button>
      <button class="danger" onclick="send('/relay?on=0')">MANUEL BIRAK</button>
      <button onclick="send('/relay_auto?en=1')">AUTO AÃ‡</button>
    </div>
    <div class="small">Not: MANUEL komut AUTOâ€™yu kapatÄ±r.</div>
    <div class="sep"></div>

    <h2>MOSFET Test</h2>
    <div class="btns">
      <button class="danger" onclick="send('/pulse_reset')">RESET (GPIO 7)</button>
      <button class="primary" onclick="send('/pulse_set')">SET (GPIO 15)</button>
    </div>
    <div class="small">Not: 100ms HIGH darbe.</div>
    <div class="sep"></div>

    <h2>Sifirlama Gecmisi</h2>
    <div class="kv"><div class="k">Toplam</div><div class="v mono"><span id="rstTotal">0</span></div></div>
    <div class="kv"><div class="k">Anlik / Gecmis</div><div class="v mono"><span id="rstNow">0</span> / <span id="rstHist">0</span></div></div>
    <div class="kv"><div class="k">Son Islem</div><div class="v mono"><span id="rstLastMode">YOK</span> @ <span id="rstLastSec">0</span>s</div></div>



  </div>
</div>


<script>
let paused = false; let t;
const inps = ["lInt","onD","offD","stb","div","thb","thc","thd","the"];
const keys = ["lInt","onD","offD","stable","div","thb","thc","thd","the"];

function p(){ paused=true; clearTimeout(t); }
function r(){ t=setTimeout(()=>{paused=false;},3000); }
function send(path){ fetch(path).then(_=>pull(false)); }

function fmtTime(sec){
  const m = Math.floor(sec/60);
  const s = sec%60;
  const mm = String(m).padStart(2, "0");
  const ss = String(s).padStart(2, "0");
  return mm + ":" + ss;
}

function pull(force=false){
  if(paused && !force) return;
  fetch('/status').then(r=>r.json()).then(d=>{
    document.getElementById('sStb').textContent = d.state;
    document.getElementById('sRaw').textContent = d.stateRaw;
    document.getElementById('cH').textContent = d.cpHigh.toFixed(2)+"V";
    document.getElementById('cL').textContent = d.cpLow.toFixed(2)+"V";
    document.getElementById('aH').textContent = d.adcHigh.toFixed(3)+"V";
    document.getElementById('aL').textContent = d.adcLow.toFixed(3)+"V";
    if(d.ia !== undefined) document.getElementById('i1').textContent = d.ia.toFixed(2);
    if(d.ib !== undefined) document.getElementById('i2').textContent = d.ib.toFixed(2);
    if(d.ic !== undefined) document.getElementById('i3').textContent = d.ic.toFixed(2);
    if(d.pW !== undefined) document.getElementById('pwr').textContent = (d.pW/1000.0).toFixed(2);
    if(d.eKWh !== undefined) document.getElementById('ekwh').textContent = d.eKWh.toFixed(3);
    if(d.tSec !== undefined) document.getElementById('tsec').textContent = fmtTime(d.tSec);
    if(d.phase !== undefined) document.getElementById('phase').textContent = d.phase + "F";
    if(d.wifiSsid !== undefined) document.getElementById('wifiSsid').textContent = d.wifiSsid;
    if(d.wifiLoc !== undefined) document.getElementById('wifiLoc').textContent = d.wifiLoc;
    if(d.ip !== undefined) document.getElementById('ip').textContent = d.ip;
    if(d.host !== undefined) document.getElementById('host').textContent = d.host;
    if(d.rLbl !== undefined) document.getElementById('rLbl').textContent = d.rLbl;
    if(d.rstTotal !== undefined) document.getElementById('rstTotal').textContent = d.rstTotal;
    if(d.rstNow !== undefined) document.getElementById('rstNow').textContent = d.rstNow;
    if(d.rstHist !== undefined) document.getElementById('rstHist').textContent = d.rstHist;
    if(d.rstLastMode !== undefined) document.getElementById('rstLastMode').textContent = d.rstLastMode;
    if(d.rstLastSec !== undefined) document.getElementById('rstLastSec').textContent = d.rstLastSec;

    // Ust rozetler
    const st = (d.state || "-");
    document.getElementById('badgeState').textContent = "STATE:" + st;

    const relayBadge = document.getElementById('badgeRelay');
    const rtxt = d.rLbl ? d.rLbl : "-";
    relayBadge.textContent = "R: " + rtxt;

    // Sarjdayken kablo parlasin
    if(d.state === "C") {
      relayBadge.style.backgroundColor = "rgba(0,255,170,0.3)";
    } else {
      relayBadge.style.backgroundColor = "";
    }

    inps.forEach((id, i) => {
      let el = document.getElementById(id);
      if(el && (document.activeElement !== el || force)) el.value = d[keys[i]];
    });
  });
}

function applyCal(){
  const q = new URLSearchParams();
  inps.forEach((id, i) => q.append(keys[i]==="stable"?"s":keys[i], document.getElementById(id).value));
  if(document.activeElement) document.activeElement.blur();
  fetch('/calib_apply?'+q.toString()).then(_=>{alert("Tamam"); paused=false; pull(true);});
}

setInterval(()=>pull(false), 2000);
pull(true);
</script>

</body></html>
)HTML";

static void setupWiFi() {
  // Tanimli aglar arasinda tarayarak STA modunda baglan.
  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);
  WiFi.setSleep(false);
  WiFi.disconnect(true, true);
  delay(100);
  WiFi.setHostname(kHostName);
  WiFi.mode(WIFI_STA);
  WiFi.softAPdisconnect(true);
  Serial.println("[WiFi] AP kapali, sadece STA modu aktif.");
  Serial.print("[WiFi] Hostname: ");
  Serial.println(kHostName);

  if (!wifiEventsReady) {
    wifiEventsReady = true;
    WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info) {
      Serial.print("[WiFi] Event: ");
      Serial.println((int)event);
      if (event == ARDUINO_EVENT_WIFI_STA_CONNECTED) {
        Serial.print("[WiFi] Connected SSID: ");
        Serial.println(WiFi.SSID());
      } else if (event == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) {
        Serial.print("[WiFi] Disconnected, reason: ");
        Serial.println((int)info.wifi_sta_disconnected.reason);
      } else if (event == ARDUINO_EVENT_WIFI_STA_GOT_IP) {
        Serial.print("[WiFi] Got IP: ");
        Serial.println(WiFi.localIP());
      }
    });
  }

  Serial.println("\nWi-Fi aglari eklendi:");
  size_t addedWifiCount = 0;
  for (size_t i = 0; i < (sizeof(kKnownWifis) / sizeof(kKnownWifis[0])); i++) {
    if (!hasText(kKnownWifis[i].ssid)) continue;
    wifiMulti.addAP(kKnownWifis[i].ssid, kKnownWifis[i].password);
    addedWifiCount++;
    Serial.printf(" - %s (%s)\n", kKnownWifis[i].location, kKnownWifis[i].ssid);
  }
  if (addedWifiCount == 0) {
    Serial.println(" - STA listesi bos.");
  }

  if (addedWifiCount > 0 && wifiMulti.run() == WL_CONNECTED) {
    Serial.println("");
    Serial.println("WiFi Baglandi!");
    Serial.print("Konum: ");
    Serial.println(wifiLocationForSsid(WiFi.SSID()));
    Serial.println("IP adresi: ");
    Serial.println(WiFi.localIP());
  }

  Serial.println("[WiFi] Kendi AP yayini kapali.");
  refreshMdns();
}
static void handleRoot() { server.send_P(200, "text/html", USER_HTML); }
static void handleAdmin() {
  if (!requireAdminAuth()) return;
  server.send_P(200, "text/html", MAIN_HTML);
}
static void handlePing() { server.send(200, "text/plain", "OK"); }
static void handleManifest() { server.send_P(200, "application/manifest+json", MANIFEST_JSON); }
static void handleServiceWorker() { server.send_P(200, "application/javascript", SERVICE_WORKER_JS); }
static void handleAppIcon() { server.send_P(200, "image/svg+xml", APP_ICON_SVG); }

static void handleStatus() {
  auto m = pilot_get();

  float ia = safeFinite(current_sensor_get_irms_a());
  float ib = safeFinite(current_sensor_get_irms_b());
  float ic = safeFinite(current_sensor_get_irms_c());
  bool relaySet = relay_get();
  bool chargingState = (m.stateStable == "C" || m.stateStable == "D");
  bool accountingEnabled = relaySet && pwmEnabled && chargingState;
  if (!accountingEnabled) {
    ia = 0.0f;
    ib = 0.0f;
    ic = 0.0f;
  }
  float pW = accountingEnabled ? safeFinite(g_powerW) : 0.0f;
  float eKWh = safeFinite(g_energyKWh);
  float cpHigh = safeFinite(m.cpHigh);
  float cpLow = safeFinite(m.cpLow);
  float adcHigh = safeFinite(m.adcHigh);
  float adcLow = safeFinite(m.adcLow);
  const char* relayLabel = relaySet ? "SET" : "RESET";
  float iMax = ia;
  if (ib > iMax) iMax = ib;
  if (ic > iMax) iMax = ic;

  String wifiSsid = "-";
  String wifiLoc = "-";
  String ipStr = "-";
  String hostStr = String(kHostName) + ".local";
  bool staOk = (WiFi.status() == WL_CONNECTED && WiFi.localIP()[0] != 0);
  if (staOk) {
    wifiSsid = WiFi.SSID();
    wifiLoc = wifiLocationForSsid(wifiSsid);
    ipStr = WiFi.localIP().toString();
  }

  int alarmLv = 0;
  const char* alarmTxt = "Sistem normal";
  if (m.stateStable == "E" || m.stateStable == "F") {
    alarmLv = 2;
    alarmTxt = "Pilot hata durumu";
  } else if (iMax > (g_currentLimitA + 1.0f)) {
    alarmLv = 1;
    alarmTxt = "Akim limiti ustu";
  } else if (!staOk) {
    alarmLv = 1;
    alarmTxt = "Wi-Fi baglantisi yok";
  }

  char json[1440];
  snprintf(
    json, sizeof(json),
    "{\"lInt\":%d,\"onD\":%lu,\"offD\":%lu,\"stable\":%d,"
    "\"cpHigh\":%.2f,\"cpLow\":%.2f,\"adcHigh\":%.3f,\"adcLow\":%.3f,"
    "\"stateRaw\":\"%s\",\"ia\":%.2f,\"ib\":%.2f,\"ic\":%.2f,"
    "\"pW\":%.1f,\"eKWh\":%.3f,\"tSec\":%lu,\"phase\":%d,\"rLbl\":\"%s\","
    "\"wifiSsid\":\"%s\",\"wifiLoc\":\"%s\",\"ip\":\"%s\",\"host\":\"%s\","
    "\"state\":\"%s\",\"div\":%.3f,\"thb\":%.2f,\"thc\":%.2f,\"thd\":%.2f,\"the\":%.2f,"
    "\"modeId\":%d,\"mode\":\"%s\",\"limitA\":%.1f,\"staOk\":%d,"
    "\"alarmLv\":%d,\"alarmTxt\":\"%s\","
    "\"sLive\":%d,\"sLiveStart\":%lu,\"sLiveSec\":%lu,\"sLiveKWh\":%.3f,"
    "\"rstTotal\":%lu,\"rstNow\":%lu,\"rstHist\":%lu,\"rstLastSec\":%lu,\"rstLastMode\":\"%s\"}",
    loopIntervalMs,
    (unsigned long)relayOnDelayMs,
    (unsigned long)relayOffDelayMs,
    stableCount,
    cpHigh, cpLow, adcHigh, adcLow,
    m.stateRaw.c_str(),
    ia, ib, ic,
    pW, eKWh,
    (unsigned long)g_chargeSeconds,
    g_phaseCount,
    relayLabel,
    wifiSsid.c_str(),
    wifiLoc.c_str(),
    ipStr.c_str(),
    hostStr.c_str(),
    m.stateStable.c_str(),
    CP_DIVIDER_RATIO,
    TH_B_MIN, TH_C_MIN, TH_D_MIN, TH_E_MIN,
    g_chargeMode,
    chargeModeLabel(g_chargeMode),
    safeFinite(g_currentLimitA),
    staOk ? 1 : 0,
    alarmLv,
    alarmTxt,
    g_sessionLive ? 1 : 0,
    (unsigned long)g_sessionLiveStartSec,
    (unsigned long)g_sessionLiveSeconds,
    safeFinite(g_sessionLiveEnergyKWh),
    (unsigned long)s_resetTotalCount,
    (unsigned long)s_resetNowCount,
    (unsigned long)s_resetHistoryCount,
    (unsigned long)s_resetLastSec,
    resetModeLabel(s_resetLastModeId)
  );

  server.send(200, "application/json", json);
}

static void handleHistory() {
  char json[4096];
  int n = 0;
  n += snprintf(
    json + n, sizeof(json) - n,
    "{\"count\":%d,\"active\":{\"on\":%d,\"start\":%lu,\"sec\":%lu,\"kWh\":%.3f},\"items\":[",
    g_histCount,
    g_sessionLive ? 1 : 0,
    (unsigned long)g_sessionLiveStartSec,
    (unsigned long)g_sessionLiveSeconds,
    safeFinite(g_sessionLiveEnergyKWh)
  );

  int start = (g_histCount < 20) ? 0 : g_histHead;
  for (int i = 0; i < g_histCount && n < (int)sizeof(json) - 2; i++) {
    int idx = (start + i) % 20;
    n += snprintf(
      json + n, sizeof(json) - n,
      "%s{\"s\":%lu,\"d\":%lu,\"e\":%.3f,\"p\":%.1f,\"ph\":%u}",
      (i == 0) ? "" : ",",
      (unsigned long)g_histStartSec[idx],
      (unsigned long)g_histDurationSec[idx],
      safeFinite(g_histEnergyKWh[idx]),
      safeFinite(g_histAvgPowerW[idx]),
      (unsigned)g_histPhaseCount[idx]
    );
  }
  snprintf(json + n, sizeof(json) - n, "]}");
  server.send(200, "application/json", json);
}

static void handleChargeCmd() {
  if (!server.hasArg("m")) {
    server.send(400, "text/plain", "missing m");
    return;
  }
  int mode = clampIntArg(server.arg("m"), 0, 2);
  g_chargeMode = mode;
  server.send(200, "text/plain", "OK");
}

static void handleDataReset() {
  bool clearNow = true;
  bool clearHistory = true;
  if (server.hasArg("now")) {
    clearNow = (server.arg("now") != "0");
  }
  if (server.hasArg("hist")) {
    clearHistory = (server.arg("hist") != "0");
  }
  if (clearNow) {
    resetChargeData(clearHistory);
  } else if (clearHistory) {
    resetHistoryData();
  }
  noteResetEvent(clearNow, clearHistory);

  char json[96];
  snprintf(
    json, sizeof(json),
    "{\"ok\":1,\"now\":%d,\"hist\":%d}",
    clearNow ? 1 : 0,
    clearHistory ? 1 : 0
  );
  server.send(200, "application/json", json);
}

static void handleCalibApply() {
  if (!requireAdminAuth()) return;
  if (server.hasArg("lInt")) {
    loopIntervalMs = clampIntArg(server.arg("lInt"), 20, 2000);
  }
  if (server.hasArg("onD")) {
    relayOnDelayMs = (uint32_t)clampIntArg(server.arg("onD"), 0, 60000);
  }
  if (server.hasArg("offD")) {
    relayOffDelayMs = (uint32_t)clampIntArg(server.arg("offD"), 0, 60000);
  }
  if (server.hasArg("s")) {
    stableCount = clampIntArg(server.arg("s"), 1, 50);
  }
  if (server.hasArg("div")) {
    CP_DIVIDER_RATIO = clampFloatArg(server.arg("div"), 0.1f, 20.0f, CP_DIVIDER_RATIO);
  }
  if (server.hasArg("thb")) {
    TH_B_MIN = clampFloatArg(server.arg("thb"), 0.0f, 15.0f, TH_B_MIN);
  }
  if (server.hasArg("thc")) {
    TH_C_MIN = clampFloatArg(server.arg("thc"), 0.0f, 15.0f, TH_C_MIN);
  }
  if (server.hasArg("thd")) {
    TH_D_MIN = clampFloatArg(server.arg("thd"), 0.0f, 15.0f, TH_D_MIN);
  }
  if (server.hasArg("the")) {
    TH_E_MIN = clampFloatArg(server.arg("the"), 0.0f, 15.0f, TH_E_MIN);
  }
  server.send(200, "text/plain", "OK");
}

static void handleRelay() {
  if (server.hasArg("on")) relay_set(server.arg("on") == "1");
  server.send(200, "text/plain", "OK");
}

static void handleRelayAuto() {
  if (server.hasArg("en")) relay_set_auto_enabled(server.arg("en") == "1");
  server.send(200, "text/plain", "OK");
}

static void handlePulseReset() {
  if (!requireAdminAuth()) return;
  pulseGpio(MOSFET_RESET_PIN);
  server.send(200, "text/plain", "OK");
}

static void handlePulseSet() {
  if (!requireAdminAuth()) return;
  pulseGpio(MOSFET_SET_PIN);
  server.send(200, "text/plain", "OK");
}



void web_init() {
  setupWiFi();
  setupArduinoOta();
  s_resetPrefsReady = s_resetPrefs.begin("evse", false);
  if (s_resetPrefsReady) {
    loadResetStats();
  } else {
    Serial.println("[RST] NVS init fail");
  }
  pinMode(MOSFET_RESET_PIN, OUTPUT);
  pinMode(MOSFET_SET_PIN, OUTPUT);
  digitalWrite(MOSFET_RESET_PIN, LOW);
  digitalWrite(MOSFET_SET_PIN, LOW);
  server.on("/", HTTP_GET, handleRoot);
  server.on("/admin", HTTP_GET, handleAdmin);
  server.on("/ping", HTTP_GET, handlePing);
  server.on("/manifest.json", HTTP_GET, handleManifest);
  server.on("/sw.js", HTTP_GET, handleServiceWorker);
  server.on("/app-icon.svg", HTTP_GET, handleAppIcon);
  // Captive portal probe endpoints (Android/iOS/Windows)
  server.on("/generate_204", HTTP_GET, handleRoot);
  server.on("/hotspot-detect.html", HTTP_GET, handleRoot);
  server.on("/fwlink", HTTP_GET, handleRoot);
  server.on("/status", HTTP_GET, handleStatus);
  server.on("/history", HTTP_GET, handleHistory);
  server.on("/data_reset", HTTP_GET, handleDataReset);
  server.on("/charge_cmd", HTTP_GET, handleChargeCmd);
  server.on("/calib_apply", HTTP_GET, handleCalibApply);
  server.on("/relay", HTTP_GET, handleRelay);
  server.on("/relay_auto", HTTP_GET, handleRelayAuto);
  server.on("/pulse_reset", HTTP_GET, handlePulseReset);
  server.on("/pulse_set", HTTP_GET, handlePulseSet);
  server.onNotFound(handleRoot);
  ElegantOTA.begin(&server, kAdminUser, kAdminPassword);
  server.begin();
}

void web_loop() {
  ArduinoOTA.handle();
  server.handleClient();
  ElegantOTA.loop();

  // WiFi yeniden baglanti denemesi: seyrek ve kisa timeout ile.
  static uint32_t lastWifiTryMs = 0;
  const uint32_t nowTry = millis();
  if (WiFi.status() != WL_CONNECTED && (nowTry - lastWifiTryMs >= 30000)) {
    lastWifiTryMs = nowTry;
    wifiMulti.run(120);
  }

  static bool printed = false;
  static uint32_t lastStatusPrintMs = 0;

  if (WiFi.status() == WL_CONNECTED) {
    if (!printed) {
      printed = true;
      Serial.print("STA SSID: ");
      Serial.println(WiFi.SSID());
      Serial.print("STA IP: ");
      Serial.println(WiFi.localIP());
      Serial.print("HOST: http://");
      Serial.print(kHostName);
      Serial.println(".local");
    }
  } else {
    printed = false; 
    const uint32_t now = millis();
    if (now - lastStatusPrintMs >= 30000) {
      lastStatusPrintMs = now;
      Serial.print("[WiFi] Status: ");
      Serial.println((int)WiFi.status());
    }
  }

  refreshMdns();
}

