#include "oled_ui.h"
#include "app_pins.h"
#include <U8g2lib.h>
#include <WiFi.h>
#include <Wire.h>

// 0.96" 128x64 SSD1306 I2C
// Reset pini yoksa U8X8_PIN_NONE kullanılır
static U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(
  U8G2_R0,              
  U8X8_PIN_NONE
);
static bool oledAvailable = false;

static bool probe_oled_addr(uint8_t addr)
{
  Wire.beginTransmission(addr);
  return (Wire.endTransmission() == 0);
}

// T10X benzeri SUV silüeti
static void draw_t10x_silhouette(int x, int y)
{
  // Gövde çizgisi
  u8g2.drawLine(x+4,  y+18, x+76, y+18);
  u8g2.drawLine(x+8,  y+10, x+22, y+6);
  u8g2.drawLine(x+22, y+6,  x+50, y+6);
  u8g2.drawLine(x+50, y+6,  x+66, y+12);
  u8g2.drawLine(x+66, y+12, x+76, y+12);
  u8g2.drawLine(x+76, y+12, x+80, y+18);
  u8g2.drawLine(x+4,  y+18, x+8,  y+10);

  // Camlar
  u8g2.drawFrame(x+22, y+8, 18, 7);
  u8g2.drawFrame(x+41, y+8, 17, 7);

  // Far (ön)
  u8g2.drawBox(x+76, y+14, 4, 2);

  // Tekerler
  u8g2.drawCircle(x+22, y+18, 6, U8G2_DRAW_ALL);
  u8g2.drawCircle(x+62, y+18, 6, U8G2_DRAW_ALL);
  u8g2.drawDisc  (x+22, y+18, 2, U8G2_DRAW_ALL);
  u8g2.drawDisc  (x+62, y+18, 2, U8G2_DRAW_ALL);
}

// Kablo + fiş + "32A" etiketi
static void draw_cable_32A(int x, int y, bool cableConnected)
{
  // Kablo hattı
  u8g2.drawLine(x, y, x+14, y);
  u8g2.drawLine(x+14, y, x+22, y+6);
  u8g2.drawLine(x+22, y+6, x+30, y+6);

  // 32A etiketi
  u8g2.drawFrame(x+2, y-10, 22, 9);
  u8g2.setFont(u8g2_font_5x7_tf);
  u8g2.drawStr(x+5, y-3, "32A");

  // Fiş
  if (cableConnected) u8g2.drawBox(x+30, y-4, 10, 10);
  else                u8g2.drawFrame(x+30, y-4, 10, 10);

  // Dişler
  u8g2.drawLine(x+33, y-7, x+33, y-4);
  u8g2.drawLine(x+37, y-7, x+37, y-4);
}

void oled_init()
{
  // I2C başlatma (Pinlerin app_pins.h içinde tanımlı olması şart!)
  // Genelde ESP32-S3 için Wire.begin(SDA, SCL) kullanılır.
  Wire.begin(OLED_SDA, OLED_SCL);
  Wire.setClock(400000); // Ekran hızı (400kHz idealdir)

  // OLED yoksa I2C bloklamasini engellemek icin tamamen pas gec.
  if (probe_oled_addr(0x3C) || probe_oled_addr(0x3D)) {
    oledAvailable = true;
  } else {
    oledAvailable = false;
    return;
  }

  u8g2.begin();
  
  // Ekranı temizle ve açılış mesajını göster
  u8g2.clearBuffer();
  u8g2.setFont(u8g2_font_6x10_tf);
  u8g2.drawStr(10, 30, "Rotosis EVSE");
  u8g2.drawStr(10, 45, "Baslatiliyor...");
  u8g2.sendBuffer();
}

void oled_draw(const String& stateStable,
               float ia,
               float ib,
               float ic,
               float powerW,
               float energyKwh,
               uint32_t chargeSeconds,
               bool relayOn,
               bool staConnected,
               bool cableConnected)
{
  if (!oledAvailable) return;
  (void)cableConnected;
  u8g2.clearBuffer();

  u8g2.setFont(u8g2_font_6x10_tf);

  // Line 1: State + Relay (SET/RESET)
  char line1[22];
  snprintf(line1, sizeof(line1), "ST:%s R:%s", stateStable.c_str(), relayOn ? "SET" : "RESET");
  u8g2.drawStr(2, 10, line1);

  // Line 2: I1/I2
  char line2[22];
  snprintf(line2, sizeof(line2), "I1:%.1f I2:%.1f", ia, ib);
  u8g2.drawStr(2, 22, line2);

  // Line 3: I3 + Power (kW)
  char line3[22];
  snprintf(line3, sizeof(line3), "I3:%.1f P:%.1f", ic, powerW / 1000.0f);
  u8g2.drawStr(2, 34, line3);

  // Line 4: Energy + Time
  uint32_t mm = chargeSeconds / 60;
  uint32_t ss = chargeSeconds % 60;
  char line4[26];
  snprintf(line4, sizeof(line4), "E:%.3fkWh T:%02lu:%02lu", energyKwh, (unsigned long)mm, (unsigned long)ss);
  u8g2.drawStr(2, 46, line4);

  // Line 5: IP
  u8g2.setFont(u8g2_font_5x7_tf);
  String ipLine;
  if (staConnected && WiFi.localIP()[0] != 0) {
      ipLine = "IP:" + WiFi.localIP().toString();
  } else {
      ipLine = "IP:Bekleniyor...";
  }
  u8g2.drawStr(2, 62, ipLine.c_str());

  u8g2.sendBuffer();
}
